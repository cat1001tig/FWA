#pragma once
// satellite_scheduler_base.h
#pragma once
#include <vector>
#include <string>
#include <memory>
#include <random>
#include "coverage_loader.h"
#include "satellite_scheduler_api.h"


class SatelliteSchedulerBase {
protected:
    std::vector<std::vector<int>> compressed_;
    std::vector<int> bounds_;
    int m_;

    // �㷨���� - ����ͨ�����캯������
    AlgorithmParams params_;

    std::unique_ptr<CoverageDataLoader> coverage_loader_;
    std::random_device rd_;
    std::mt19937 gen_;

public:
    // �޸Ĺ��캯���Խ��ܲ���
    SatelliteSchedulerBase(const AlgorithmParams& params = AlgorithmParams());
    virtual ~SatelliteSchedulerBase() = default;

    bool loadCompressedData(const std::string& filename);
    void initializeCoverageLoader();

    const std::vector<std::vector<int>>& getCompressed() const { return compressed_; }
    const std::vector<int>& getBounds() const { return bounds_; }
    int getSatelliteCount() const { return m_; }

    // ��ȡ�����ò����ĺ���
    const AlgorithmParams& getParams() const { return params_; }
    void setParams(const AlgorithmParams& params) { params_ = params; }

protected:
    std::vector<std::vector<int>> parseCompressedData(const std::vector<std::string>& lines);
    std::vector<int> parseBoundsData(const std::string& bounds_line);
};
