// csv_parser.cpp

#include "pch.h"
#include "csv_parser.h"
#include <fstream>
#include <sstream>
#include <stdexcept>

// ʵ�־�̬��Ա���� - ע�⣺���ﲻ��Ҫдstatic�ؼ���
std::vector<std::vector<std::string>> CSVParser::parseCSV(const std::string& filename, char delimiter) {
    std::vector<std::vector<std::string>> result;
    std::ifstream file(filename);

    if (!file.is_open()) {
        throw std::runtime_error("�޷���CSV�ļ�: " + filename);
    }

    std::string line;
    while (std::getline(file, line)) {
        // ��������
        if (line.empty() || (line.find_first_not_of(" \t\r\n") == std::string::npos)) {
            continue;
        }

        auto row = parseCSVLine(line, delimiter);
        if (!row.empty()) {
            result.push_back(row);
        }
    }

    return result;
}

std::vector<std::string> CSVParser::parseCSVLine(const std::string& line, char delimiter) {
    std::vector<std::string> result;
    std::stringstream ss(line);
    std::string cell;

    while (std::getline(ss, cell, delimiter)) {
        result.push_back(cell);
    }

    // �������һ���ֶο���Ϊ�յ����
    if (!line.empty() && line.back() == delimiter) {
        result.push_back("");
    }

    return result;
}