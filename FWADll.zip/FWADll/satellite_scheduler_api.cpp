// satellite_scheduler_api.cpp

// �����ڰ����κ�ͷ�ļ�֮ǰ���������
#define SATELLITESCHEDULER_EXPORTS

#include "pch.h"  // Ԥ����ͷ�ļ�
#include "satellite_scheduler_api.h"
#include "satellite_data_loader.h"
#include "coverage_loader.h"
#include "satellite_scheduler_multiobjective.h"
#include <memory>
#include <iostream>
#include <sstream>

// ȫ�ִ�����Ϣ
static std::string g_last_error;


SATELLITE_API void InitializeSchedulingResult(SchedulingResult* result) {
    if (result) {
        result->success = false;
        result->error_message = "";
        result->best_solutions.clear();
    }
}

SATELLITE_API void FreeSchedulingResult(SchedulingResult* result) {
    if (result) {
        // vector ���Զ�����
        result->best_solutions.clear();
    }
}

// SchedulerWrapper ��ʵ��
class SchedulerWrapper {
private:
    std::unique_ptr<SatelliteSchedulerMultiObjective> scheduler_;
    AlgorithmParams params_;
    std::vector<std::vector<std::vector<int>>> last_best_solutions_;  // �洢�ϴεĽ��

public:
    SchedulerWrapper(const AlgorithmParams* params) : params_(*params) {
        try {
            // ʹ�� reset ������ make_unique ������ģ������Ƶ�����
            scheduler_.reset(new SatelliteSchedulerMultiObjective(params_));
        }
        catch (const std::exception& e) {
            g_last_error = "Failed to create scheduler: " + std::string(e.what());
            throw;
        }
    }

    bool executeScheduling(
        const char* compressed_data_file,
        int num_iterations,
        int population_size,
        int random_seed,
        int start_hour,
        int start_minute,
        int start_second,
        int end_hour,
        int end_minute,
        int end_second,
        SchedulingResult* result
    ) {
        if (!result) {
            g_last_error = "Result pointer is null";
            return false;
        }

        try {
            // ����۲�ʱ�䷶Χ
            int endSeconds = end_hour * 3600 + end_minute * 60 + end_second;
            int startSeconds = start_hour * 3600 + start_minute * 60 + start_second;
            int diffSeconds = endSeconds - startSeconds;
            if (diffSeconds < 0) {
                diffSeconds += 24 * 3600;
            }
            int diffMinutes = diffSeconds / 60;
            params_.total_minutes_ = diffMinutes + 1;

            // 1. ������������
            SatelliteDataLoader dloader;
            if (!dloader.loadDataFromExcel(params_.directoryPath)) {
                result->success = false;
                result->error_message = "Failed to load satellite data from: " + params_.directoryPath;
                g_last_error = result->error_message;
                return false;
            }

            // ����ѹ������
            dloader.saveCompressedData(compressed_data_file);

            // 2. ����ѹ�����ݵ�������
            if (!scheduler_->loadCompressedData(compressed_data_file)) {
                result->success = false;
                result->error_message = "Failed to load compressed data from: " + std::string(compressed_data_file);
                g_last_error = result->error_message;
                return false;
            }

            // ���ø��������ݺ�ʱ������
            scheduler_->setCoverageData(dloader.getCoverageData());
            scheduler_->setTimeIndices(dloader.getTimeIndices());

            // 3. ��ʼ�������ʼ�����
            scheduler_->initializeCoverageLoader();

            // 4. ִ���Ż�
            auto optimize_result = scheduler_->optimize(num_iterations, population_size, random_seed);
            last_best_solutions_ = std::get<0>(optimize_result);  // ������

            return true;

        }
        catch (const std::exception& e) {
            result->success = false;
            result->error_message = "Exception during scheduling: " + std::string(e.what());
            g_last_error = result->error_message;
            return false;
        }
        catch (...) {
            result->success = false;
            result->error_message = "Unknown exception during scheduling";
            g_last_error = result->error_message;
            return false;
        }
    }
    // �����������ڰ�ȫ�ط��ʽ��
    int getSolutionCount() const {
        return static_cast<int>(last_best_solutions_.size());
    }
    bool getSolutionInfo(int solution_index, int* satellite_count, double* coverage, double* variance) {
        if (solution_index < 0 || solution_index >= last_best_solutions_.size()) {
            return false;
        }

        try {
            auto eval_result = scheduler_->evaluate(last_best_solutions_[solution_index], false);
            *satellite_count = eval_result.satellite_count;
            *coverage = eval_result.coverage;
            *variance = eval_result.load_variance;
            return true;
        }
        catch (...) {
            return false;
        }
    }
    int getAssignmentCount(int solution_index, int satellite_index) {
        if (solution_index < 0 || solution_index >= last_best_solutions_.size()) {
            return 0;
        }
        if (satellite_index < 0 || satellite_index >= last_best_solutions_[solution_index].size()) {
            return 0;
        }
        return static_cast<int>(last_best_solutions_[solution_index][satellite_index].size());
    }

    int getAssignment(int solution_index, int satellite_index, int task_index) {
        if (solution_index < 0 || solution_index >= last_best_solutions_.size()) {
            return -1;
        }
        if (satellite_index < 0 || satellite_index >= last_best_solutions_[solution_index].size()) {
            return -1;
        }
        if (task_index < 0 || task_index >= last_best_solutions_[solution_index][satellite_index].size()) {
            return -1;
        }
        return last_best_solutions_[solution_index][satellite_index][task_index];
    }
};

// ʵ���µĵ�������
SATELLITE_API int GetSolutionCount(void* scheduler) {
    if (!scheduler) return 0;
    auto wrapper = static_cast<SchedulerWrapper*>(scheduler);
    return wrapper->getSolutionCount();
}

SATELLITE_API bool GetSolutionInfo(void* scheduler, int solution_index,
    int* satellite_count, double* coverage, double* variance) {
    if (!scheduler || !satellite_count || !coverage || !variance) return false;
    auto wrapper = static_cast<SchedulerWrapper*>(scheduler);
    return wrapper->getSolutionInfo(solution_index, satellite_count, coverage, variance);
}

SATELLITE_API int GetAssignmentCount(void* scheduler, int solution_index, int satellite_index) {
    if (!scheduler) return 0;
    auto wrapper = static_cast<SchedulerWrapper*>(scheduler);
    return wrapper->getAssignmentCount(solution_index, satellite_index);
}

SATELLITE_API int GetAssignment(void* scheduler, int solution_index, int satellite_index, int task_index) {
    if (!scheduler) return -1;
    auto wrapper = static_cast<SchedulerWrapper*>(scheduler);
    return wrapper->getAssignment(solution_index, satellite_index, task_index);
}

// DLL �������� - ��Щ����Ӧ���� SATELLITE_API
SATELLITE_API void* CreateScheduler(const AlgorithmParams* params) {
    try {
        g_last_error = "";
        if (!params) {
            g_last_error = "Parameters pointer is null";
            return nullptr;
        }
        return new SchedulerWrapper(params);
    }
    catch (const std::exception& e) {
        g_last_error = "CreateScheduler exception: " + std::string(e.what());
        return nullptr;
    }
    catch (...) {
        g_last_error = "Unknown exception in CreateScheduler";
        return nullptr;
    }
}

SATELLITE_API void DestroyScheduler(void* scheduler) {
    g_last_error = "";
    if (scheduler) {
        delete static_cast<SchedulerWrapper*>(scheduler);
    }
}

SATELLITE_API bool ExecuteScheduling(
    void* scheduler,
    const char* compressed_data_file,
    int num_iterations,
    int population_size,
    int random_seed,
    int start_hour,
    int start_minute,
    int start_second,
    int end_hour,
    int end_minute,
    int end_second,
    SchedulingResult* result
) {
    g_last_error = "";
    if (!scheduler) {
        if (result) {
            result->success = false;
            result->error_message = "Scheduler is null";
        }
        g_last_error = "Scheduler is null";
        return false;
    }

    if (!result) {
        g_last_error = "Result pointer is null";
        return false;
    }

    auto wrapper = static_cast<SchedulerWrapper*>(scheduler);
    return wrapper->executeScheduling(
        compressed_data_file,
        num_iterations,
        population_size,
        random_seed,
        start_hour,
        start_minute,
        start_second,
        end_hour,
        end_minute,
        end_second,
        result
    );
}

SATELLITE_API const char* GetSchedulerLastError() {
    return g_last_error.c_str();
}