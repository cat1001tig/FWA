#pragma once

#include "pch.h"
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>

class OptimizedCSVReader {
public:
    static std::vector<bool> readSingleColumnCSV(const std::string& filepath, int expected_rows = -1);

private:
    static std::string trim(const std::string& str);
    static bool parseBoolValue(const std::string& str);
};