// csv_parser.h - ��ȷ�ķ�ʽ
#pragma once
#include <vector>
#include <string>

class CSVParser {
public:
    static std::vector<std::vector<std::string>> parseCSV(const std::string& filename, char delimiter = ',');
    static std::vector<std::string> parseCSVLine(const std::string& line, char delimiter = ',');
};